<?php


namespace DgoraWcas;


class Multilingual
{

    /**
     * Check if the website is multilangual
     * @return bool
     */
    public function isMultilingual(){

    }

    /**
     * Check if WPMl is active
     * @return bool
     */
    public function isWPML(){

    }

    /**
     * Current language
     * @return string
     */
    public function getCurrentLanguage(){

    }


}